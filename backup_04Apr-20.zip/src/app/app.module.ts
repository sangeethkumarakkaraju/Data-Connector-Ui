import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { HomeComponent } from './feature/home/home.component';
import { AppRoutingModule } from './app-routing.module';
import { SharedModule } from './shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { FormsModule } from '@angular/forms';
import { SchedulerComponent } from './feature/data-connection/scheduler/scheduler.component';
import { FromsourceComponent } from './feature/data-connection/fromsource/fromsource.component';
import { TosourceComponent } from './feature/tablecomponent/tosource/tosource.component';
import { DataConnectorService } from './shared/dataconnector/data-connector.service';
import { DataConnectionComponent } from './feature/data-connection/data-connection.component';
import { TablecomponentComponent } from './feature/tablecomponent/tablecomponent.component';

import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';


@NgModule({
  declarations: [
    DataConnectionComponent,
    AppComponent,
    HomeComponent,
    SchedulerComponent,
    FromsourceComponent,
    TosourceComponent,
    TablecomponentComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    SharedModule,
    FormsModule,

  ],
  providers: [DataConnectorService,
    {
      provide: MatDialogRef,
      useValue: {}
    }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
