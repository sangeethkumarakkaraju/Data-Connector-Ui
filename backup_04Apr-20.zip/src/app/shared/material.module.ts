import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatSliderModule, MatInputModule, MatFormFieldModule, MatCardModule, MatButtonModule, MatIconModule, MatDialogModule, MatExpansionModule, MatStepperModule, MatAutocompleteModule, MatGridListModule, MatSelectModule, MatCheckboxModule, MatTooltipModule, MatMenuModule, MatError, MatPaginatorModule } from '@angular/material';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { MatNativeDateModule, MatRippleModule } from '@angular/material/core';
import { MatTableModule } from '@angular/material/table';
import { TableModule } from 'primeng/table';

import { CdkTableModule } from '@angular/cdk/table';




@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    MatSliderModule,
    MatInputModule,
    MatFormFieldModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatMenuModule,
    MatDialogModule,
    MatExpansionModule,
    MatStepperModule,
    MatAutocompleteModule,
    MatGridListModule,
    MatSelectModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatTableModule,
    TableModule,
    CdkTableModule,
    MatPaginatorModule



  ],
  exports: [
    MatSliderModule,
    MatInputModule,
    MatFormFieldModule,
    MatMenuModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatDialogModule,
    MatExpansionModule,
    MatStepperModule,
    MatAutocompleteModule,
    MatGridListModule,
    MatSelectModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatDatepickerModule,
    MatNativeDateModule,
    MatTableModule,
    TableModule,
    CdkTableModule,
    MatPaginatorModule


  ]
})
export class MaterialModule { }
