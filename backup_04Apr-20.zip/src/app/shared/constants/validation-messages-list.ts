export const FILLING_NEEDED_MESSAGE = 'Need to fill';
export const EMAIL_PATTERN_MESSAGE = 'Incorrect Email';
export const CYRILLIC_PATTERN_MESSAGE = 'Only cyrillic';