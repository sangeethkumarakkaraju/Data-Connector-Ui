import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { NavbarComponent } from './shared/layouts/navbar/navbar.component';
import { DataConnectionComponent } from './feature/data-connection/data-connection.component';
import { HomeComponent } from './feature/home/home.component';
import { FromsourceComponent } from './feature/data-connection/fromsource/fromsource.component';
import { TosourceComponent } from './feature/tablecomponent/tosource/tosource.component';
import { SchedulerComponent } from './feature/data-connection/scheduler/scheduler.component';
import { TablecomponentComponent } from './feature/tablecomponent/tablecomponent.component';

const routes: Routes = [
  {
    path: '', component: HomeComponent,
    data: { shownavbar: false }
  },
  {
    path: 'table', component: TablecomponentComponent,
    data: { shownavbar: false }
  },
  {
    path: 'from', component: FromsourceComponent,
    data: { shownavbar: true }
  },
  {
    path: 'to', component: TosourceComponent,
    data: { shownavbar: true }
  },
  {
    path: 'data-point', component: DataConnectionComponent,
    data: { shownavbar: true }
  },
  {
    path: 'data-connector', component: TablecomponentComponent,
    data: { shownavbar: true }
  },
  {
    path: 'scheduler', component: SchedulerComponent,
    data: { shownavbar: true }
  }
];

@NgModule({
  declarations: [],
  imports: [
    RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
