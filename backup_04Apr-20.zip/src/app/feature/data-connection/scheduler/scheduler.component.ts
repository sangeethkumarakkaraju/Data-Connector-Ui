import { Component, ViewChild, ElementRef, OnInit } from '@angular/core';

import { Observable, Subject } from 'rxjs';
import { Subscription } from "rxjs";
import { DataService } from '../services/shared.service';
import { map, scan } from 'rxjs/operators';


@Component({
  selector: 'app-scheduler',
  templateUrl: './scheduler.component.html',
  styleUrls: ['./scheduler.component.scss']
})
export class SchedulerComponent implements OnInit {
  connected: Subscription;
  address: any = 'wss://echo.websocket.org';
  message: any = 'ping';
  messages: Subject<any> = new Subject();
  messageLog: any;
  scrollEndNow = false;
  constructor(private dataservice: DataService) {

  }

  ngOnInit() {
    this.connect();
  }

  connect() {
    this.messages = <Subject<any>>this.dataservice
      .connect(this.address)
      .pipe(map((response: MessageEvent): any => {
        return response.data;
      }));
    this.messageLog = this.messages.pipe(scan((current, change) => {
      return [...current, `RESPONSE: ${change}`]
    }, []));
  }

  send() {
    this.messages.next(this.message);
  }

}
