import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { FromsourceComponent } from './fromsource/fromsource.component';
import { MatTableDataSource, MatSort } from '@angular/material';


import { MatDialog, MatTable } from '@angular/material';



const ELEMENT_DATA: any = [{
  createdon: new Date().getTime(),
  createdby: localStorage.getItem('data'),
  name: 'Data Point 1',
  url: 'http://3.208.113.126:8000/sap/bc/srt/wsdl/flv_10002P111AD1/sdef_url/Z_READ_CUST2?sap-client=800',
  type: "sap",
  inout: 'inbound',
  id: new Date().getTime(),
}];

@Component({
  selector: 'app-data-connection',
  templateUrl: './data-connection.component.html',
  styleUrls: ['./data-connection.component.scss']
})


export class DataConnectionComponent implements OnInit {
  dataSource = [{
    createdon: new Date().getTime(),
    createdby: localStorage.getItem('data'),
    name: 'Data Point 1',
    url: 'http://3.208.113.126:8000/sap/bc/srt/wsdl/flv_10002P111AD1/sdef_url/Z_READ_CUST2?sap-client=800',
    type: 'sap',
    inout: 'Inbound',
    id: new Date().getTime(),
  }]
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  positionFilter = new FormControl();
  nameFilter = new FormControl();
  globalFilter = '';

  filteredValues = {
    position: '', name: '', weight: '',
    symbol: ''
  };
  ngOnInit() {
    this.positionFilter.valueChanges.subscribe((positionFilterValue) => {
      this.filteredValues['position'] = positionFilterValue;
      // this.dataSource.filter = JSON.stringify(this.filteredValues);
    });

    this.nameFilter.valueChanges.subscribe((nameFilterValue) => {
      this.filteredValues['name'] = nameFilterValue;
      //this.dataSource.filter = JSON.stringify(this.filteredValues);
    });

    //  this.dataSource.filterPredicate = this.customFilterPredicate();

  }


  customFilterPredicate() {
    const myFilterPredicate = (data: any, filter: string): boolean => {
      var globalMatch = !this.globalFilter;

      if (this.globalFilter) {
        // search all text fields
        globalMatch = data.name.toString().trim().toLowerCase().indexOf(this.globalFilter.toLowerCase()) !== -1;
      }

      if (!globalMatch) {
        return;
      }

      let searchString = JSON.parse(filter);
      return data.position.toString().trim().indexOf(searchString.position) !== -1 &&
        data.name.toString().trim().toLowerCase().indexOf(searchString.name.toLowerCase()) !== -1;
    }
    return myFilterPredicate;
  }

  displayedColumns: string[] = ['id', 'name', 'inout', 'type', 'createdby', 'createdon', 'updatedby', 'updatedon', 'action'];

  action = "Add";
  @ViewChild(MatTable, { static: true }) table: MatTable<any>;

  dataArray = [];




  currtentTime: Date;
  dataSource1: any;

  index: any;
  constructor(private dialog: MatDialog) { }

  openDialog(action, obj): void {
    obj.action = action;
    const dialogRef = this.dialog.open(FromsourceComponent, {
      width: '500px',
      data: obj
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result.event == 'Add') {
        console.log(result);
        this.addRowData(result.data);
      } else if (result.event == 'Update') {
        this.updateRowData(result.data);
      } else if (result.event == 'Delete') {
        this.deleteRowData(result.data);
      }
    });

  }
  addRowData(row_obj) {
    var d = new Date();
    console.log(row_obj);
    this.dataSource.push({
      createdon: d.getTime(),
      createdby: localStorage.getItem('data'),
      name: row_obj.name,
      url: row_obj.url,
      type: row_obj.type,
      inout: row_obj.inout,
      id: d.getTime()
    });
    localStorage.setItem('datapoint', JSON.stringify(this.dataSource))
    console.log(this.dataSource)
    this.table.renderRows();

  }


  updateRowData(row_obj) {
    this.dataSource = this.dataSource.filter((value, key) => {
      if (value.id == row_obj.id) {
        value.name = row_obj.name;
        value.url = row_obj.url;
        value.type = row_obj.type;
        value.inout = row_obj.inout;

      }
      return true;
    });
  }

  deleteRowData(row_obj) {
    this.dataSource = this.dataSource.filter((value, key) => {
      return value.id != row_obj.id;
    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    //  this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  connectionType = [
    { value: 'sales Force', viewValue: 'Sales Force' },
    { value: 'SAP', viewValue: 'SAP' },
    { value: 'NoSQL', viewValue: 'NoSQL' },
    { value: 'PID', viewValue: 'PID' }
  ];
  authorization = [
    { value: 'tokaen', viewValue: 'Token' },
    { value: 'userName', viewValue: 'User Name' }
  ];

}
