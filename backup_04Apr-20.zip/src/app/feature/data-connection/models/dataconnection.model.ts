export class dataconnection {
  id: number;
  type: string;
  url: string;
  inout: string;
  created_at: string;
  created_by: string;
  updated_at: string;
}
