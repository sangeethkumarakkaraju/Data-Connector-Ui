import { Component, OnInit, Input, Output, EventEmitter, Inject, Optional } from '@angular/core';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';

import { MAT_DIALOG_DATA } from '@angular/material';

import { MatDialogRef } from '@angular/material/dialog';

import { dataconnection } from '../models/dataconnection.model';
export interface UsersData {
  name: string;
  id: number;
}
@Component({
  selector: 'app-fromsource',
  templateUrl: './fromsource.component.html',
  styleUrls: ['./fromsource.component.scss']
})
export class FromsourceComponent implements OnInit {


  //firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;



  action: string;
  local_data: any;

  constructor(private fb: FormBuilder, public dialogRef: MatDialogRef<FromsourceComponent>,

    @Optional() @Inject(MAT_DIALOG_DATA) public data: UsersData) {
    console.log(data);
    this.local_data = { ...data };
    this.action = this.local_data.action;
  }

  datapointform: FormGroup;
  datapointarray: Array<any> = [];
  ngOnInit() {
    this.datapointform = this.fb.group({
      type: new FormControl(),
      url: new FormControl(),
      inout: new FormControl(),
      name: new FormControl(),

    });

  }
  doAction() {
    this.dialogRef.close({ event: this.action, data: this.local_data });
  }

  closeDialog() {
    this.dialogRef.close({ event: 'Cancel' });
  }


}
