import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FromsourceComponent } from './fromsource.component';

describe('FromsourceComponent', () => {
  let component: FromsourceComponent;
  let fixture: ComponentFixture<FromsourceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FromsourceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FromsourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
