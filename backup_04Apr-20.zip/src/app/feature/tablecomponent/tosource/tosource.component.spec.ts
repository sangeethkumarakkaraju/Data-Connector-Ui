import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TosourceComponent } from './tosource.component';

describe('TosourceComponent', () => {
  let component: TosourceComponent;
  let fixture: ComponentFixture<TosourceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TosourceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TosourceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
