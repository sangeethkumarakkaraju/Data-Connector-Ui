import { Component, ViewChild, OnInit } from '@angular/core';
import { MatTableDataSource, MatDialog, MatSort, MatTable } from '@angular/material';
import { MatPaginator } from '@angular/material/paginator';

import { DataSource } from '@angular/cdk/collections';
import { Observable, of } from 'rxjs';
import { TosourceComponent } from './tosource/tosource.component';
import { IfStmt } from '@angular/compiler';
import { FormControl } from '@angular/forms';
import { FromsourceComponent } from '../data-connection/fromsource/fromsource.component';


@Component({
  selector: 'app-tablecomponent',
  templateUrl: './tablecomponent.component.html',
  styleUrls: ['./tablecomponent.component.scss']
})
export class TablecomponentComponent implements OnInit {

  dataSource = [{
    createdon: new Date().getTime(),
    createdby: localStorage.getItem('data'),
    name: 'NewData connection',
    url: 'http://3.208.113.126:8000/sap/bc/srt/wsdl/flv_10002P111AD1/sdef_url/Z_READ_CUST2?sap-client=800',
    type: 'SAP',
    inbound: 'InBoundData Point',
    outbound: 'SAP Data Point',
    id: new Date().getTime(),
  }]
  @ViewChild(MatSort, { static: true }) sort: MatSort;

  positionFilter = new FormControl();
  nameFilter = new FormControl();
  globalFilter = '';

  filteredValues = {
    position: '', name: '', weight: '',
    symbol: ''
  };
  ngOnInit() {
    this.positionFilter.valueChanges.subscribe((positionFilterValue) => {
      this.filteredValues['position'] = positionFilterValue;
      //   this.dataSource.filter = JSON.stringify(this.filteredValues);
    });

    this.nameFilter.valueChanges.subscribe((nameFilterValue) => {
      this.filteredValues['name'] = nameFilterValue;
      //  this.dataSource.filter = JSON.stringify(this.filteredValues);
    });

    //  this.dataSource.filterPredicate = this.customFilterPredicate();

  }


  customFilterPredicate() {
    const myFilterPredicate = (data: any, filter: string): boolean => {
      var globalMatch = !this.globalFilter;

      if (this.globalFilter) {
        // search all text fields
        globalMatch = data.name.toString().trim().toLowerCase().indexOf(this.globalFilter.toLowerCase()) !== -1;
      }

      if (!globalMatch) {
        return;
      }

      let searchString = JSON.parse(filter);
      return data.position.toString().trim().indexOf(searchString.position) !== -1 &&
        data.name.toString().trim().toLowerCase().indexOf(searchString.name.toLowerCase()) !== -1;
    }
    return myFilterPredicate;
  }

  displayedColumns: string[] = ['id', 'name', 'inbound', 'outbound', 'createdby', 'createdon', 'updatedby', 'updatedon', 'action'];

  action = "Add";
  @ViewChild(MatTable, { static: true }) table: MatTable<any>;

  dataArray = [];




  currtentTime: Date;
  dataSource1: any;

  index: any;
  constructor(private dialog: MatDialog) { }

  openDialog(action, obj): void {
    obj.action = action;
    const dialogRef = this.dialog.open(FromsourceComponent, {
      width: '500px',
      data: obj
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result.event == 'Add') {
        console.log(result);
        this.addRowData(result.data);
      } else if (result.event == 'Update') {
        this.updateRowData(result.data);
      } else if (result.event == 'Delete') {
        this.deleteRowData(result.data);
      }
    });

  }
  addRowData(row_obj) {
    var d = new Date();
    console.log(row_obj);

    localStorage.setItem('datapoint', JSON.stringify(this.dataSource))
    console.log(this.dataSource)
    this.table.renderRows();

  }


  updateRowData(row_obj) {
    this.dataSource = this.dataSource.filter((value, key) => {
      if (value.id == row_obj.id) {


      }
      return true;
    });
  }

  deleteRowData(row_obj) {
    this.dataSource = this.dataSource.filter((value, key) => {
      return value.id != row_obj.id;
    });
  }

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    //  this.dataSource.filter = filterValue.trim().toLowerCase();
  }

  connectionType = [
    { value: 'sales Force', viewValue: 'Sales Force' },
    { value: 'SAP', viewValue: 'SAP' },
    { value: 'NoSQL', viewValue: 'NoSQL' },
    { value: 'PID', viewValue: 'PID' }
  ];
  authorization = [
    { value: 'tokaen', viewValue: 'Token' },
    { value: 'userName', viewValue: 'User Name' }
  ];
}






